<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Indonesia | CekCorona</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="css/css/materialize.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="js/jquery.js"></script>
    <script src="css/js/materialize.min.js"></script>
</head>
<body>
    <div>
        <nav class="indigo">
            <div class="nav-wraper container">
                    <ul class="side-nav" id="mobile-menu">
                        <h5 style="color:black; text-align:center; ">CekCorona</h5>
                        <li><a href="index.php"><i class="material-icons left">home</i> Home</a></li>
                        <li><a href="indonesia.php"><i class="material-icons left">flag</i> Indonesia</a></li>
                        <li><a href="globe.php"><i class="material-icons left">language</i>Globe</a></li>
                    </ul>
                    <a href="#!" data-activates="mobile-menu" class="button-collapse">
                            <i class="material-icons">clear_all</i>
                        </a>
                <a href="#!" class="brand-logo">CekCorona</a>
                <ul class="right hide-on-med-and-down">
                    <li><a href="index.php"><i class="material-icons left">home</i>| Home |</a></li>
                    <li><a href="indonesia.php"><i class="material-icons left">flag</i>| Indonesia |</a></li>
                    <li><a href="globe.php"><i class="material-icons left">language</i>| Globe |</a></li>
                </ul>
            </div>
        </nav>
    </div>

    <!-- Start  Contain index -->
    <div class="container">
        <h3 class="center">CekCorona Indonesia</h3>
        <h6 class="center">Sumber data : Kementerian Kesehatan & JHU. Update terakhir : <span id="date"></span></h6>
        </br></br></br>
        <div class="row">
                <div class="col s12 m4">
                    <div class="card-panel light-blue lighten-1">
                        <span class="white-text">
                            <img class="img-logo-index left" src="https://kawalcorona.com/uploads/sad-u6e.png" width="30%" height="30%" alt="Logo Daerah">
                            <h5 class="center"><span id='terjangkit'></span></h5>
                            <p class="center">TOTAL POSITIF</p>
                        </span>
                    </div>
                </div>
                <div class="col s12 m4">
                    <div class="card-panel green lighten-1">
                        <span class="white-text">
                            <img class="img-logo-index left" src="https://kawalcorona.com/uploads/happy-ipM.png" width="30%" height="30%" alt="Logo Daerah">
                            <h5 class="center"><span id='sembuh'></span></h5>
                            <p class="center">TOTAL SEMBUH</p>
                        </span>
                    </div>
                </div>
                <div class="col s12 m4">
                    <div class="card-panel red lighten-1">
                        <span class="white-text">
                            <img class="img-logo-index left" src="https://kawalcorona.com/uploads/emoji-LWx.png" width="30%" height="30%" alt="Logo Daerah">
                            <h5 class="white-text center"><span id='meninggal'></span></h5>
                            <p class="center">TOTAL MENINGGAL</p>
                        </span>
                    </div>
                </div>
            </div>
    </div>
     <!-- Close  Contain index -->
     <?php 
        $data = file_get_contents('https://api.kawalcorona.com/indonesia/provinsi');
        $data_dua = json_decode($data, true)
     ?>
     <!-- Start Table -->
     <div class="container">
     <table class="bordered striped white centered responsive-table">
        <thead>
          <tr>
              <th>No.</th>
              <th>PROVINSI</th>
              <th>POSITIF</th>
              <th>SEMBUH</th>
              <th>MENINGGAL</th>
          </tr>
        </thead>
        <tbody>
            <?php $i=1; ?>
            <?php foreach ( $data_dua as $dtd ) : ?>
          <tr>
            <td><?= $i; ?></td>
            <td><?= $dtd['attributes']['Provinsi']; ?></td>
            <td><?= $dtd['attributes']['Kasus_Posi']; ?></td>
            <td><?= $dtd['attributes']['Kasus_Semb']; ?></td>
            <td><?= $dtd['attributes']['Kasus_Meni']; ?></td>
          </tr>
          <?php $i++; ?>
            <?php endforeach; ?>
        </tbody>
      </table>
      </div>
      <!--Close Table-->
        <br><br><br><br><br>
     <!-- Start Footer -->
    <footer>
        <div class="center">
            <div class="row">
                <div class="page-copyright">
                    <p class="black-text">Powered by <a href="https://web.facebook.com/lampungprov.go.id">Geraldine Firdaus</a> . Data Live By &copy; <a href="https://kawalcorona.com/"> Ethical Hacker Indonesia</a>. </p>
                </div>
            </div>
        </div>
    </footer>
     <!-- Close Footer -->


    <script src="js/script.js"></script>
</body>
</html>
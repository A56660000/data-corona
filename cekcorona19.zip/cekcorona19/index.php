<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home | CekCorona</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="css/css/materialize.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="js/jquery.js"></script>
    <script src="css/js/materialize.min.js"></script>
</head>
<body>
    <div>
        <nav class="indigo">
            <div class="nav-wraper container">
                    <ul class="side-nav" id="mobile-menu">
                        <h5 style="color:black; text-align:center; ">CekCorona</h5>
                        <li><a href="index.php"><i class="material-icons left">home</i> Home</a></li>
                        <li><a href="indonesia.php"><i class="material-icons left">flag</i> Indonesia</a></li>
                        <li><a href="globe.php"><i class="material-icons left">language</i>Globe</a></li>
                    </ul>
                    <a href="#!" data-activates="mobile-menu" class="button-collapse">
                            <i class="material-icons">clear_all</i>
                        </a>
                <a href="#!" class="brand-logo">CekCorona</a>
                <ul class="right hide-on-med-and-down">
                    <li><a href="index.php"><i class="material-icons left">home</i>| Home |</a></li>
                    <li><a href="indonesia.php"><i class="material-icons left">flag</i>| Indonesia |</a></li>
                    <li><a href="globe.php"><i class="material-icons left">language</i>| Globe |</a></li>
                </ul>
            </div>
        </nav>
    </div>

    <!-- Start  Contain index -->
    <div class="container">
        <h3 class="center">Coronavirus Hotline Indonesia</h3>
        <h6 class="center">Layanan darurat via telepon yang disediakan oleh Kemkes</h6>
        </br></br></br>
        <div class="row">
            <div class="col s12 m4">
                <div class="card-panel">
                    <span class="indigo-text">
                        <img class="img-logo-index center" src="https://kawalcorona.com/uploads/unnamed-9mT.png" width="30%" height="30%" alt="Logo Daerah">
                        <h4><a href="tel:0215210411"><h5 class="mb-2 center">(021) 5210411</h5></a></h4>
                        <p class="center">Kementrian Kesehatan</p>
                    </span>
                </div>
            </div>
            <div class="col s12 m4">
                <div class="card-panel">
                    <span class="indigo-text">
                        <img class="img-logo-index center" src="https://kawalcorona.com/uploads/unnamed-9mT.png" width="30%" height="30%" alt="Logo Daerah">
                        <h4><a href="tel:081212123119"><h5 class="mb-2 center">(0812) 12123119</h5></a></h4>
                        <p class="center">Kementrian Kesehatan</p>
                    </span>
                </div>
            </div>
            <div class="col s12 m4">
                <div class="card-panel">
                    <span class="indigo-text">
                        <img class="img-logo-index center" src="https://dinkes.lampungprov.go.id/wp-content/uploads/2019/07/lampung2.png" width="65%" height="65%" alt="Logo Daerah">
                        <h4><a href="tel:0721252412"><h5 class="mb-2 center">(0721) 252412</h5></a></h4>
                        <p class="center">Kamkes Lampung</p>
                    </span>
                </div>
            </div>
        </div>
    </div>
     <!-- Close  Contain index -->
        <br><br><br><br>
     <!-- Start Footer -->
    <footer>
        <div class="center">
            <div class="row">
                <div class="page-copyright">
                    <p class="black-text">Powered by <a href="https://web.facebook.com/lampungprov.go.id">Geraldine Firdaus</a> . Data Live By &copy; <a href="https://kawalcorona.com/"> Ethical Hacker Indonesia</a>. </p>
                </div>
            </div>
        </div>
    </footer>
     <!-- Close Footer -->


    <script src="js/script.js"></script>
</body>
</html>